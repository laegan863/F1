@extends('index')
@section("title", "Demographics Profile")
@section("nav_title", "DEMOGRAPHIC PROFILE OF PATIENT")
@section("content")
    <form id="form" method="POST" action="{{ route('submit-demograpic-profile') }}">
        @csrf
        <div class="card-body p-5">
            {{-- {{ Session::get('hospitalID') }} --}}
            @php
                $session = Session::get('patient');
            @endphp
            <div class="row mb-3">
                <div class="col-md-4 mb-3">
                    <label for="firstName" class="form-label">Date of Patient's First Encounter<small class="text-danger">*</small></label>
                    <input type="date" class="form-control" value="{{ old('patient_first_encounter', \Carbon\Carbon::now()->toDateString()) }}" name="patient_first_encounter" id="" autofocus>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Patient’s Health Facility ID No.<small class="text-danger">*</small></label>
                    <input type="text" class="form-control" value="{{ old('patient_health_facility_id', Session::get('patient')->HospitalID ?? '') }}" name="patient_health_facility_id" id="" placeholder="Enter Patient’s Health Facility ID No.">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="lastName" class="form-label">PhilHealth Identification No. (PIN)<small class="text-danger">*</small></label>
                    <input minlength="12" maxlength="13" type="text" class="form-control" value="{{ old('philhealth_id') }}" name="philhealth_id" id="" placeholder="Enter PhilHealth Identification No. (PIN)">
                </div>
                <div class="col-md-3">
                    <label for="firstName" class="form-label">First Name<small class="text-danger">*</small></label>
                    <input type="text" class="form-control" value="{{ old('name.firstname', $session ? $session->FirstName : '') }}" name="name[firstname]" id="firstName" placeholder="Enter first name" autofocus>
                </div>
                <div class="col-md-3">
                    <label for="middleName" class="form-label">Middle Name</label>
                    <input type="text" class="form-control" value="{{ old('name.middlename', $session ? $session->MiddleName : '') }}" name="name[middlename]" id="middleName" placeholder="Enter middle name">
                </div>
                <div class="col-md-3">
                    <label for="lastName" class="form-label">Last Name<small class="text-danger">*</small></label>
                    <input type="text" class="form-control" value="{{ old('name.lastname', $session ? $session->LastName : '') }}" name="name[lastname]" id="lastName" placeholder="Enter last name">
                </div>
                <div class="col-md-3">
                    <label for="suffix" class="form-label">Suffix<small class="text-danger">*</small></label>
                    <select class="form-select" id="suffix" name="name[suffix]">
                        <option disabled {{ old('name.suffix') ? '' : 'selected' }}>Choose...</option>
                        <option value="Jr." {{ old('name.suffix') == 'Jr.' ? 'selected' : '' }}>Jr.</option>
                        <option value="Sr." {{ old('name.suffix') == 'Sr.' ? 'selected' : '' }}>Sr.</option>
                        <option value="II"  {{ old('name.suffix') == 'II'  ? 'selected' : '' }}>II</option>
                        <option value="III" {{ old('name.suffix') == 'III' ? 'selected' : '' }}>III</option>
                        <option value="IV"  {{ old('name.suffix') == 'IV'  ? 'selected' : '' }}>IV</option>
                        <option value="V"   {{ old('name.suffix') == 'V'   ? 'selected' : '' }}>V</option>
                        <option value="N/A" {{ old('name.suffix') == 'N/A' || $session && $session->Suffix == null ? 'selected' : '' }}>N/A</option>
                    </select>

                </div>
                <div class="col-md-12 mt-3">
                    <label for="married" class="form-label">If Married, Maiden Name <small class="text-danger">(optional)</small></label>
                    <input type="text" class="form-control" name="married_maiden_name" value="{{ old('married_maiden_name') }}" id="married" placeholder="Enter Maiden Name">
                </div>
            </div>
            @php
                $date = $session ? \Carbon\Carbon::parse($session->Birthdate)->toDateString() : "";
            @endphp
            <div class="row mb-3">
                <div class="col-md-3">
                    <label for="dob" class="form-label">Date of Birth<small class="text-danger">*</small></label>
                    <input type="date" class="form-control" value="{{ old('date_of_birth', $date) }}" name="date_of_birth" id="dob">
                </div>
                <div class="col-md-3">
                        <label for="sex" class="form-label">Sex at Birth<small class="text-danger">*</small></label>
                        <select class="form-select" name="sex" id="sex">
                            <option disabled {{ old('sex') ? '' : 'selected' }}>Choose...</option>
                            <option value="male"   {{ old('sex') == 'male' || $session && $session->Gender == "Male" ? 'selected' : '' }}>Male</option>
                            <option value="female" {{ old('sex') == 'female' || $session && $session->Gender == "Female" ? 'selected' : '' }}>Female</option>
                        </select>
                </div>
                <div class="col-md-3">
                    <label for="civilStatus" class="form-label">Civil Status<small class="text-danger">*</small></label>
                    <select class="form-select" name="civil_status" id="civilStatus">
                        <option disabled {{ old('civil_status') ? '' : 'selected' }}>Choose...</option>
                        <option value="Single" {{ old('civil_status') == 'Single' || $session && $session->CivilStatus == "SINGLE" ? 'selected' : '' }}>Single</option>
                        <option value="Married" {{ old('civil_status') == 'Married' || $session && $session->CivilStatus == strtoupper("Married") ? 'selected' : '' }}>Married</option>
                        <option value="Divorced/Separated/Annulled" {{ old('civil_status') == 'Divorced/Separated/Annulled' || $session && $session->CivilStatus == strtoupper("Divorced/Separated/Annulled") ? 'selected' : '' }}>Divorced/Separated/Annulled</option>
                        <option value="Common-law/Live-in" {{ old('civil_status') == 'Common-law/Live-in' || $session && $session->CivilStatus == strtoupper("Common-law/Live-in") ? 'selected' : '' }}>Common-law/Live-in</option>
                        <option value="Widowed" {{ old('civil_status') == 'Widowed' || $session && $session->CivilStatus == strtoupper("Widowed") ? 'selected' : '' }}>Widowed</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="nationality" class="form-label">Nationality<small class="text-danger">*</small></label>
                    <input type="text" class="form-control" value="{{ old('nationality', $session ? $session->Nationality : '') }}" name="nationality" id="nationality" placeholder="e.g. Filipino">
                </div>
            </div>

            <div class="mb-3">
                <label for="permanentAddress" class="form-label fw-semibold">Permanent Address</label>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="province" class="form-label">Province<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" id="province" name="permanent[province]">
                            <option value="">Select Province</option>
                        </select> --}}
                        <input type="text" name="permanent[province]" value="{{ old('permanent.province') }}" class="form-control">

                    </div>
                    <div class="col-md-4">
                        <label for="city" class="form-label">City/Municipality<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" name="permanent[city]" id="city" disabled>
                            <option value="">Select City</option>
                        </select> --}}
                        <input type="text" name="permanent[city]" value="{{ old('permanent.city') }}" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="barangay" class="form-label">Barangay<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" name="permanent[barangay]" id="barangay" disabled>
                            <option value="">Select Barangay</option>
                        </select> --}}
                        <input type="text" name="permanent[barangay]" value="{{ old('permanent.barangay') }}" class="form-control">
                    </div>
                    {{-- <div class="col-md-3">
                        <label for="sitio" class="form-label">Sitio<small class="text-danger">*</small></label>
                        <input type="text" class="form-control" name="permanent[sitio]" id="sitio" placeholder="Enter Sitio">
                    </div> --}}
                </div>
            </div>

            <div class="mb-3" >
                <label for="currentAddress" class="form-label fw-semibold">Current Address</label>
                <div class="row mb-3 {{ old('same_as_address') ? 'd-none' : '' }}" id="current_address">
                    <div class="col-md-4">
                        <label for="curretprovince" class="form-label">Province<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" name="current[province]" id="currentprovince">
                            <option value="">Select Province</option>
                        </select> --}}
                        <input type="text" name="current[province]" value="{{ old('current.province') }}" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="currentcity" class="form-label">City/Municipality<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" name="current[city]" id="currentcity" disabled>
                            <option value="">Select City</option>
                        </select> --}}
                        <input type="text" name="current[city]" value="{{ old('current.city') }}" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="currentbarangay" class="form-label">Barangay<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" name="current[barangay]" id="currentbarangay" disabled>
                            <option value="">Select Barangay</option>
                        </select> --}}
                        <input type="text" name="current[barangay]" value="{{ old('current.barangay') }}" class="form-control">
                    </div>
                    {{-- <div class="col-md-3">
                        <label for="currentsitio" class="form-label">Sitio<small class="text-danger">*</small></label>
                        <input type="text" value="" name="current[sitio]" class="form-control" id="currentsitio" placeholder="Enter Sitio">
                    </div> --}}
                </div>

                <div class="form-check mt-1">
                <input
                    class="form-check-input"
                    type="checkbox"
                    id="sameAddress"
                    name="same_as_address"
                    value="on"
                    {{ old('same_as_address') ? 'checked' : '' }}>
                    <label class="form-check-label" for="sameAddress">
                        Same as Permanent Address
                    </label>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="mobile" class="form-label">Mobile No.<small class="text-danger">*</small></label>
                    <input type="tel" class="form-control" id="mobile" value="{{ old('mobile_number', $session ? $session->ContactNo : "") }}" name="mobile_number" placeholder="09123456789">
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label">Email Address<small class="text-danger">*</small></label>
                    <input type="email" class="form-control" id="email" name="email_address" value="{{ old('email_address', $session ? $session->Email : "") }}" placeholder="example@email.com">
                </div>
            </div>

            <div class="mb-3">
                <label for="permanentAddress" class="form-label fw-semibold">Nearest Relative / Legal Guardian Permanent Address</label>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="province" class="form-label">Province<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" id="relativeprovince" value="{{ old('relative.province') }}" name="relative[province]">
                            <option value="">Select Province</option>
                        </select> --}}
                        <input type="text" name="relative[province]" value="{{ old('relative.province') }}" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="city" class="form-label">City/Municipality<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" id="relativecity" value="{{ old('relative.city') }}" name="relative[city]" disabled>
                            <option value="">Select City</option>
                        </select> --}}
                        <input type="text" name="relative[city]" value="{{ old('relative.city') }}" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="barangay" class="form-label">Barangay<small class="text-danger">*</small></label>
                        {{-- <select class="form-select" id="relativebarangay" value="{{ old('relative.barangay') }}" name="relative[barangay]" disabled>
                            <option value="">Select Barangay</option>
                        </select> --}}
                        <input type="text" name="relative[barangay]" value="{{ old('relative.barangay') }}" class="form-control">
                    </div>
                    {{-- <div class="col-md-3">
                        <label for="sitio" class="form-label">Sitio<small class="text-danger">*</small></label>
                        <input type="text" class="form-control" id="relativesitio" value="{{ old('relative.sitio') }}" name="relative[sitio]" placeholder="Enter Sitio">
                    </div> --}}
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="mobile" class="form-label">Nearest Relative / Legal Guardian Mobile Contact No. <small class="text-danger">*</small></label>
                    <input type="tel" class="form-control" id="mobile" value="{{ old('relative_phone_number') }}" name="relative_phone_number" placeholder="09123456789">
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label">Nearest Relative / Legal Guardian Email Address <small class="text-danger">(optional)</small></label>
                    <input type="email" class="form-control" id="email" value="{{ old('relative_email') }}" name="relative_email" placeholder="example@email.com">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="education" class="form-label">Highest Level of Education <small class="text-danger">*</small></label>
                        <select class="form-select" name="highest_education" id="education">
                            <option disabled {{ old('highest_education') ? '' : 'selected' }}>Choose...</option>
                            <option value="Elementary" {{ old('highest_education') == 'Elementary' ? 'selected' : '' }}>Elementary</option>
                            <option value="Secondary" {{ old('highest_education') == 'Secondary' ? 'selected' : '' }}>Secondary</option>
                            <option value="Tertiary" {{ old('highest_education') == 'Tertiary' ? 'selected' : '' }}>Tertiary</option>
                            <option value="Adult School" {{ old('highest_education') == 'Adult School' ? 'selected' : '' }}>Adult School</option>
                            <option value="No Education" {{ old('highest_education') == 'No Education' ? 'selected' : '' }}>No Education</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="occupation" class="form-label">Occupation <small class="text-danger">*</small></label>
                        <select class="form-select" name="occupation" id="occupation">
                            <option value="" disabled {{ old('occupation') ? '' : 'selected' }}>Choose...</option>
                            <option value="Managers" {{ old('occupation') == 'Managers' ? 'selected' : '' }}>Managers</option>
                            <option value="Professionals" {{ old('occupation') == 'Professionals' ? 'selected' : '' }}>Professionals</option>
                            <option value="Technicians and Associate Professionals" {{ old('occupation') == 'Technicians and Associate Professionals' ? 'selected' : '' }}>Technicians & Associate Professionals</option>
                            <option value="Clerical Support Workers" {{ old('occupation') == 'Clerical Support Workers' ? 'selected' : '' }}>Clerical Support Workers</option>
                            <option value="Service and Sales Workers" {{ old('occupation') == 'Service and Sales Workers' ? 'selected' : '' }}>Service and Sales Workers</option>
                            <option value="Skilled Agricultural Workers" {{ old('occupation') == 'Skilled Agricultural Workers' ? 'selected' : '' }}>Skilled Agricultural Workers</option>
                            <option value="Craft and Related Trades Workers" {{ old('occupation') == 'Craft and Related Trades Workers' ? 'selected' : '' }}>Craft and Related Trades Workers</option>
                            <option value="Plant and Machine Operators" {{ old('occupation') == 'Plant and Machine Operators' ? 'selected' : '' }}>Plant and Machine Operators</option>
                            <option value="Elementary Occupations" {{ old('occupation') == 'Elementary Occupations' ? 'selected' : '' }}>Elementary Occupations</option>
                            <option value="Armed Forces Occupations" {{ old('occupation') == 'Armed Forces Occupations' ? 'selected' : '' }}>Armed Forces Occupations</option>
                            <option value="Unemployed Retired" {{ old('occupation') == 'Unemployed Retired' ? 'selected' : '' }}>Unemployed/Retired</option>
                            <option value="N/A" {{ old('occupation') == 'N/A' ? 'selected' : '' }}>N/A</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="yearsOccupation" class="form-label">Number of Years in Occupation <small class="text-danger"><small class="text-danger">*</small></label>
                <input type="number" class="form-control" value="{{ old('number_of_years_in_occupation') }}" name="number_of_years_in_occupation" id="yearsOccupation" placeholder="e.g. 15">
            </div>
        </div>

        <div class="card-footer text-end">
            <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
            <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
        </div>
    </form>
@endsection
@section("script")
    <script>
        function handleSubmit() {
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to submit this form?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, submit it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById("form").submit();
                }
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            const sameAddressCheckbox = document.getElementById("sameAddress");
            const currentAddressSection = document.getElementById('current_address');
            
            // Function to copy permanent address to current address
            function copyPermanentToCurrent() {
                document.querySelector('input[name="current[province]"]').value = document.querySelector('input[name="permanent[province]"]').value;
                document.querySelector('input[name="current[city]"]').value = document.querySelector('input[name="permanent[city]"]').value;
                document.querySelector('input[name="current[barangay]"]').value = document.querySelector('input[name="permanent[barangay]"]').value;
            }

            // Function to clear current address fields
            function clearCurrentAddress() {
                document.querySelector('input[name="current[province]"]').value = '';
                document.querySelector('input[name="current[city]"]').value = '';
                document.querySelector('input[name="current[barangay]"]').value = '';
            }

            // Handle checkbox change
            sameAddressCheckbox.addEventListener("change", function () {
                if (this.checked) {
                    currentAddressSection.classList.add('d-none');
                    copyPermanentToCurrent();
                } else {
                    currentAddressSection.classList.remove('d-none');
                    clearCurrentAddress();
                }
            });

            // Update current address when permanent address changes (if checkbox is checked)
            const permanentFields = document.querySelectorAll('input[name^="permanent["]');
            permanentFields.forEach(field => {
                field.addEventListener('input', function() {
                    if (sameAddressCheckbox.checked) {
                        copyPermanentToCurrent();
                    }
                });
            });

            // If checkbox is already checked on page load, copy the values
            if (sameAddressCheckbox.checked) {
                copyPermanentToCurrent();
            }
        });
    </script>
@endsection
