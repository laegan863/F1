<?php $__env->startSection("title", "ESAS-r Assessment"); ?>
<?php $__env->startSection("nav_title", "A. ESAS-r (Edmonton Symptom Assessment System Revised)"); ?>
<?php $__env->startSection("content"); ?>
    <form id="form" method="POST" action="" class="p-2">
        <?php echo csrf_field(); ?>

        <!-- GCS & ESAS-r Score -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">GCS Score of the Patient</label>
                        <input type="number" name="gcs_score" class="form-control" min="0" max="15">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">ESAS-r Score of the Patient <small>(Only if GCS Score ≥ 8)</small></label>
                        <input type="number" name="esasr_score" class="form-control" min="0" max="100">
                    </div>
                </div>
            </div>
        </div>

        <!-- Symptom Scales -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Please circle the number that best describes how the patient feels NOW:</h5>

                <?php $__currentLoopData = [
                    'pain'=>'No Pain|Worst Possible Pain',
                    'tiredness'=>'No Tiredness|Worst Possible Tiredness',
                    'drowsiness'=>'No Drowsiness|Worst Possible Drowsiness',
                    'nausea'=>'No Nausea|Worst Possible Nausea',
                    'appetite'=>'No Lack of Appetite|Worst Possible Lack of Appetite',
                    'breath'=>'No Shortness of Breath|Worst Possible Shortness of Breath',
                    'depression'=>'No Depression|Worst Possible Depression',
                    'anxiety'=>'No Anxiety|Worst Possible Anxiety',
                    'wellbeing'=>'Best Wellbeing|Worst Possible Wellbeing'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$labels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        [$left,$right] = explode('|',$labels);
                    ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold text-uppercase"><?php echo e(ucfirst($key)); ?></label>
                        <div class="d-flex">
                            <span class="me-2"><?php echo e($left); ?></span>
                            <div class="d-flex flex-wrap">
                                <?php for($i=0;$i<=10;$i++): ?>
                                    <div class="form-check form-check-inline">
                                        <input type="radio" name="<?php echo e($key); ?>" value="<?php echo e($i); ?>" class="form-check-input">
                                        <label class="form-check-label"><?php echo e($i); ?></label>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <span class="ms-2"><?php echo e($right); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Other Problem -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Other Problem</label>
                    <input type="text" name="other_problem" class="form-control mb-2" placeholder="Describe problem">
                    <div class="d-flex align-items-center">
                        <span class="me-2">
                            <input type="text" name="" id="" placeholder="title" class="form-control">
                        </span>
                        <div class="d-flex flex-wrap">
                            <?php for($i=0;$i<=10;$i++): ?>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="other_problem_score" value="<?php echo e($i); ?>" class="form-check-input">
                                    <label class="form-check-label"><?php echo e($i); ?></label>
                                </div>
                            <?php endfor; ?>
                        </div>
                        <span class="ms-2">
                            <input type="text" name="" id="" placeholder="title" class="form-control">
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Submit -->
        <div class="card-footer text-end">
            <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
            <button type="submit" class="btn btn-primary rounded-0">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Laegan\F1\resources\views/forms/form4/esas-r.blade.php ENDPATH**/ ?>