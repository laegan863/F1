<?php $__env->startSection("title", "Validate Hospital Number"); ?>
<?php $__env->startSection("nav_title", "Validate Hospital Number"); ?>
<?php $__env->startSection("content"); ?>
<form id="form" method="POST" action="<?php echo e(route('admin.validate-hospital-number')); ?>">
    <?php echo csrf_field(); ?>
    <div class="card-body p-4">
        <div class="row">
            <div class="col-md-12">
                <div class="my-2">
                    <label for="">Hopital Number</label>
                    <input type="number" name="HospitalID" class="form-control" placeholder="Enter the Hopital Number" required>
                </div>
            </div>
        </div>
    </div>

    <div class="card-footer text-end">
        <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
        <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Laegan\F1\resources\views/forms/check-user-info.blade.php ENDPATH**/ ?>