<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CBCR</title>
    <link rel="icon" type="image/png" class="rounded" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link href="<?php echo e(asset(path: 'assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset(path: 'assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset(path: 'assets/css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset(path: 'assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset(path: 'assets/css/style.css')); ?>" rel="stylesheet">

</head>
<body class="">
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <img alt="image" class="rounded-circle" src="<?php echo e(asset(path: 'assets/img/profile.png')); ?>"/>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="block m-t-xs font-bold"><?php echo e(Auth::user()->name); ?></span>
                            </a>
                        </div>
                        <div class="logo-element">
                            <b>CBCR</b>
                        </div>
                    </li>
                    <li class="<?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span class="nav-label">
                                Dashboard
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->is('admin/records') ? 'active' : ''); ?>">
                        <a href="#"><i class="fa fa-th-large"></i><span class="nav-label">Record Management</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="<?php echo e(request()->is('admin/records') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('admin.records')); ?>">
                                    <i class="fa fa-list"></i>
                                    Manage Records
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('first-page')); ?>">
                                    <i class="fa fa-plus"></i>
                                    Add Record
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <li class="<?php echo e(request()->is('admin/users') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.users')); ?>">
                                <i class="fa fa-users"></i>
                                <span class="nav-label">
                                    User Management
                                </span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

            </div>
        </nav>


        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                </div>
                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <a href="<?php echo e(route('logout')); ?>">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2><?php echo e(ucwords(Request::segment(index: 2))); ?></h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="index.html"><?php echo e(ucwords(Request::segment(index: 1))); ?></a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong><?php echo e(ucwords(Request::segment(index: 2))); ?></strong>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="wrapper wrapper-content">
                <?php echo $__env->yieldContent(section: 'content'); ?>
            </div>
            <div class="footer">
                <div class="float-right">
                    <strong>CLMMRH Administrator</strong>
                </div>
                <div>
                    <strong>All Rights Reserved</strong> CLMMRH &copy; 2025
                </div>
            </div>

        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="<?php echo e(asset(path: 'assets/js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset(path: 'assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset(path: 'assets/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset(path: 'assets/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(asset(path: 'assets/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <script src="<?php echo e(asset(path: 'assets/js/plugins/dataTables/datatables.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(asset(path: 'assets/js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(asset(path: 'assets/js/plugins/pace/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sweetalert.min.js')); ?>"></script>
    <?php if(Session::has('success')): ?>
        <script>
            Swal.fire({
                title: "Good job!",
                text: "<?php echo e(Session::get('success')); ?>",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <script>
        $.fn.dataTable.Buttons.defaults.dom.button.className = 'btn btn-white btn-sm';

        $(document).ready(function () {
            $('.dataTables-example').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy' },
                    { extend: 'csv' },
                    { extend: 'excel', title: 'ExampleFile' },
                    { extend: 'pdf', title: 'ExampleFile' },

                    {
                        extend: 'print',
                        customize: function (win) {
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    }
                ]
            });
        });
    </script>
</body>
<?php /**PATH C:\xampp\htdocs\Laegan\F1\resources\views/admin/app.blade.php ENDPATH**/ ?>