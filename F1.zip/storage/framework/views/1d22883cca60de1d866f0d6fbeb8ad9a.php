<?php $__env->startSection("title", "Cancer Treatment Profile"); ?>
<?php $__env->startSection("nav_title", "PATIENT ECOG STATUS, SURGERY, & ANTI-CANCER DRUG THERAPY"); ?>
<?php $__env->startSection("content"); ?>
    <form id="form" method="POST" action="<?php echo e(route('store.patient-eco-status')); ?>" class="card">
        <?php echo csrf_field(); ?>

        <div class="card-body">
            <!-- Patient ECOG Status -->
            <h5 class="fw-bold mt-3">PATIENT ECOG STATUS</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Eastern Cooperative Oncology Group (ECOG) <small class="text-danger">*</small></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Yes','No','Not Applicable']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="radio" name="ecog_status" value="<?php echo e($opt); ?>" 
                                   class="form-check-input rounded-circle"
                                   onclick="toggleECOG()"
                                   <?php echo e(old('ecog_status','No') == $opt ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($opt); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- ECOG Grade -->
                <div id="ecogGradeSection" class="mt-2 <?php echo e(old('ecog_status')=='Yes' ? '' : 'd-none'); ?>">
                    <label class="form-label">If Yes, specify ECOG Grade</label>
                    <div class="d-flex flex-wrap gap-3">
                        <?php $__currentLoopData = ['0','1','2','3','4','5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="radio" name="ecog_grade" value="Grade <?php echo e($grade); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(old('ecog_grade') == "Grade $grade" ? 'checked' : ''); ?>>
                                <label class="form-check-label">Grade <?php echo e($grade); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Other Functional Assessment -->
            <div class="mb-3">
                <label class="form-label fw-bold">Other Functional Assessment <small class="text-danger">(optional)</small></label>
                <input type="text" name="other_functional_assessment" class="form-control" 
                       value="<?php echo e(old('other_functional_assessment')); ?>">
            </div>

            <!-- Surgery -->
            <h5 class="fw-bold mt-3">SURGERY</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Surgery Done? <small class="text-danger">*</small></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="radio" name="surgery_done" value="<?php echo e($opt); ?>" 
                                   class="form-check-input rounded-circle"
                                   onclick="toggleSurgery()"
                                   <?php echo e(old('surgery_done','No') == $opt ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($opt); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Surgery Details -->
            <div id="surgeryDetails" class="<?php echo e(old('surgery_done')=='Yes' ? '' : 'd-none'); ?>">
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label class="form-label">Surgery Type (RVS Code)</label>
                        <input type="text" name="surgery_rvs" class="form-control" value="<?php echo e(old('surgery_rvs')); ?>">
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Surgery Description</label>
                        <input type="text" name="surgery_description" class="form-control" value="<?php echo e(old('surgery_description')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Surgery Date</label>
                        <input type="date" name="surgery_date" class="form-control" value="<?php echo e(old('surgery_date')); ?>">
                    </div>
                </div>

                <label class="form-label">Goal (multiple)</label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Diagnostic','Curative','Palliative']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="checkbox" name="surgery_goal[]" value="<?php echo e($goal); ?>" 
                                   class="form-check-input rounded-circle"
                                   <?php echo e(in_array($goal, old('surgery_goal',[])) ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($goal); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Anti-Cancer Drug Therapy -->
            <h5 class="fw-bold mt-3">ANTI-CANCER DRUG THERAPY</h5>
            <div class="mb-3">
                <label class="form-label fw-bold">Ongoing Anti-cancer Drug Therapy? <small class="text-danger">*</small></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Yes','No']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="radio" name="ongoing_drug_therapy" value="<?php echo e($opt); ?>" 
                                   class="form-check-input rounded-circle"
                                   onclick="toggleDrugTherapy()"
                                   <?php echo e(old('ongoing_drug_therapy','No') == $opt ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($opt); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Drug Therapy Details -->
            <div id="drugTherapyDetails" class="<?php echo e(old('ongoing_drug_therapy')=='Yes' ? '' : 'd-none'); ?>">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Date Start</label>
                        <input type="date" name="therapy_date_start" class="form-control" value="<?php echo e(old('therapy_date_start')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Purpose</label>
                        <div class="d-flex flex-wrap gap-3">
                            <?php $__currentLoopData = ['Neoadjuvant','Adjuvant','Palliative']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purpose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input type="radio" name="drug_purpose" value="<?php echo e($purpose); ?>" 
                                           class="form-check-input rounded-circle"
                                           <?php echo e(old('drug_purpose')==$purpose ? 'checked' : ''); ?>>
                                    <label class="form-check-label"><?php echo e($purpose); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <label class="form-label">Drug Type/s (multiple)</label>
                <div class="row">
                    <?php $__currentLoopData = ['Cytotoxic','Hormonal','Immunologic','Targeted','Others']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="form-check">
                                <input type="checkbox" name="drug_types[]" value="<?php echo e($label); ?>" 
                                       class="form-check-input rounded-circle"
                                       id="drugType<?php echo e($i); ?>" onchange="toggleDrugFields(<?php echo e($i); ?>)"
                                       <?php echo e(in_array($label, old('drug_types',[])) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                            <div class="mt-2">
                                <label class="form-label small">Drug Regimen</label>
                                <input type="text" name="drug_regimen[<?php echo e($label); ?>]" class="form-control"
                                    id="drugRegimen<?php echo e($i); ?>" 
                                    value="<?php echo e(old('drug_regimen.'.$label)); ?>"
                                    <?php echo e(in_array($label, old('drug_types',[])) ? '' : 'disabled'); ?>>
                                <label class="form-label small mt-2">Chemo Cycle No.</label>
                                <input type="text" name="chemo_cycle[<?php echo e($label); ?>]" class="form-control"
                                    id="chemoCycle<?php echo e($i); ?>" 
                                    value="<?php echo e(old('chemo_cycle.'.$label)); ?>"
                                    <?php echo e(in_array($label, old('drug_types',[])) ? '' : 'disabled'); ?>>
                            </div>
                            <?php if($label == 'Others'): ?>
                                <input type="text" name="drug_type_other" class="form-control mt-2"
                                    id="drugOther<?php echo e($i); ?>" placeholder="Specify others"
                                    value="<?php echo e(old('drug_type_other')); ?>"
                                    <?php echo e(in_array('Others', old('drug_types',[])) ? '' : 'disabled'); ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Remarks</label>
                    <input type="date" name="surgery_date" class="form-control" value="<?php echo e(old('surgery_date')); ?>">
                </div>
            </div>
        </div>

        <!-- Submit -->
        <div class="card-footer text-end">
            <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
            <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script>
    function toggleECOG() {
        let yes = document.querySelector('input[name="ecog_status"][value="Yes"]').checked;
        document.getElementById('ecogGradeSection').classList.toggle('d-none', !yes);
    }
    function toggleSurgery() {
        let yes = document.querySelector('input[name="surgery_done"][value="Yes"]').checked;
        document.getElementById('surgeryDetails').classList.toggle('d-none', !yes);
    }
    function toggleDrugTherapy() {
        let yes = document.querySelector('input[name="ongoing_drug_therapy"][value="Yes"]').checked;
        document.getElementById('drugTherapyDetails').classList.toggle('d-none', !yes);
    }
    function toggleDrugFields(key) {
        let checked = document.getElementById('drugType'+key).checked;
        document.getElementById('drugRegimen'+key).disabled = !checked;
        document.getElementById('chemoCycle'+key).disabled = !checked;
        if(document.getElementById('drugOther'+key)){
            document.getElementById('drugOther'+key).disabled = !checked;
        }
    }
    // Init on load
    window.onload = function() {
        toggleECOG(); toggleSurgery(); toggleDrugTherapy();
        [0,1,2,3,4].forEach(k => toggleDrugFields(k));
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/forms/form2/patient-eco-status.blade.php ENDPATH**/ ?>