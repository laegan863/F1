<?php $__env->startSection("title", "Palliative Care Intervention"); ?>
<?php $__env->startSection("nav_title", "C. Palliative Care Intervention"); ?>
<?php $__env->startSection("content"); ?>
    <form id="form" method="POST" action="" class="p-3">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = [
            'nutritional' => 'Nutritional Care',
            'nursing' => 'Nursing Care',
            'rehabilitation' => 'Rehabilitation Care',
            'psychosocial' => 'Psychosocial Care (e.g., depression, anxiety, well-being)',
            'spiritual' => 'Spiritual Care',
            'others' => 'Other/s'
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="mb-4 border p-2">
                <label class="fw-bold"><?php echo e($label); ?></label><br>

                <!-- Yes/No -->
                <div class="form-check form-check-inline">
                    <input type="radio" name="<?php echo e($key); ?>_care" value="1" class="form-check-input rounded-circle" onclick="toggleSection('<?php echo e($key); ?>Details')">
                    <label class="form-check-label">1 Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" name="<?php echo e($key); ?>_care" value="2" class="form-check-input rounded-circle" onclick="toggleSection('<?php echo e($key); ?>Details')" checked>
                    <label class="form-check-label">2 No</label>
                </div>

                <!-- Extra fields if Yes -->
                <div id="<?php echo e($key); ?>Details" class="d-none mt-2">

                    <!-- For "Others" add specify -->
                    <?php if($key === 'others'): ?>
                        <label class="form-label">If yes, specify:</label>
                        <input type="text" name="<?php echo e($key); ?>_specify" class="form-control mb-2">
                    <?php endif; ?>

                    <label class="form-label">If yes, where is care being given mainly in:</label><br>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_place" value="1" class="form-check-input rounded-circle">
                        <label class="form-check-label">1 Home</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_place" value="2" class="form-check-input rounded-circle">
                        <label class="form-check-label">2 Hospital</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_place" value="3" class="form-check-input rounded-circle">
                        <label class="form-check-label">3 Community-based</label>
                    </div>

                    <br>
                    <label class="form-label mt-2">Is the patient’s quality of life improved with these care by 25% or more?</label><br>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_improved" value="1" class="form-check-input rounded-circle">
                        <label class="form-check-label">1 Yes</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_improved" value="2" class="form-check-input rounded-circle">
                        <label class="form-check-label">2 No</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="<?php echo e($key); ?>_improved" value="3" class="form-check-input rounded-circle">
                        <label class="form-check-label">3 Not assessed</label>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="text-end">
            <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
            <button type="submit" class="btn btn-primary rounded-0">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script>
    function toggleSection(id) {
        const section = document.getElementById(id);
        if (section) {
            const yesSelected = event.target.value === '1';
            section.classList.toggle('d-none', !yesSelected);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Laegan\F1\resources\views/forms/form4/palliative-care-intervention.blade.php ENDPATH**/ ?>