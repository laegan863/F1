<?php $__env->startSection('title', 'REPORTING FORM 1F: Status at First Encounter at Health Facility'); ?>
<?php $__env->startSection('content'); ?>
<?php
    use App\Models\Demographicprofile;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Request;
    
    if (Request::segment(2) === 'generate-report') {
        $rawData = Demographicprofile::with(['riskfactors', 'cancerdiagnoses', 'treatments'])
            ->whereBetween(DB::raw('YEAR(created_at)'), [Request::query('year_from'), Request::query('year_to')])
            ->whereBetween(DB::raw('MONTH(created_at)'), [Request::query('month_from'), Request::query('month_to')])
            ->get();
    } else {
        $rawData = $data;
    }
    // echo json_encode($rawData);
    $cancer_status_counts = [
        'Newly diagnosed' => ['male' => 0, 'female' => 0],
        'Old case, not treated' => ['male' => 0, 'female' => 0],
        'Old case, completed 1st treatment, now' => ['male' => 0, 'female' => 0],
        'Old case, incomplete treatment, now' => ['male' => 0, 'female' => 0],
        'Old case, unknown treatment' => ['male' => 0, 'female' => 0],
    ];

    foreach ($rawData as $record) {
        $sex = strtolower($record->sex ?? '');
        if ($sex !== 'male' && $sex !== 'female') continue;

        if ($record->cancerdiagnoses && $record->cancerdiagnoses->cancer_status) {
            if (isset($cancer_status_counts[$record->cancerdiagnoses->cancer_status])) {
                $cancer_status_counts[$record->cancerdiagnoses->cancer_status][$sex]++;
            }
        }
    }
?>
    <table class="w-full text-xs border border-gray-400 mt-6">
        <thead>
            <tr class="bg-gray-600 text-white font-bold">
                <th colspan="4" class="border border-gray-400 text-center py-1">STATUS OF THE CANCER CASE</th>
            </tr>
            <tr class="bg-gray-300 font-bold">
                <th class="border border-gray-400 text-left px-2">CLASSIFICATIONS</th>
                <th class="border border-gray-400 text-center">MALE</th>
                <th class="border border-gray-400 text-center">FEMALE</th>
                <th class="border border-gray-400 text-center">TOTAL</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $status_list = [
                    'Newly diagnosed',
                    'Old case, not treated',
                    'Old case, completed 1st treatment, now',
                    'Old case, incomplete treatment, now',
                    'Old case, unknown treatment'
                ];
                $total_male = 0;
                $total_female = 0;
            ?>
            <?php $__currentLoopData = $status_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $male = $cancer_status_counts[$status]['male'];
                $female = $cancer_status_counts[$status]['female'];
                $total = $male + $female;
                $total_male += $male;
                $total_female += $female;
            ?>
            <tr>
                <td class="border border-gray-400 px-2"><?php echo e($index + 1); ?> <?php echo e($status); ?></td>
                <td class="border border-gray-400 text-center"><?php echo e($male); ?></td>
                <td class="border border-gray-400 text-center"><?php echo e($female); ?></td>
                <td class="border border-gray-400 text-center"><?php echo e($total); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-gray-200 font-bold">
                <td class="border border-gray-400 px-2">TOTAL</td>
                <td class="border border-gray-400 text-center"><?php echo e($total_male); ?></td>
                <td class="border border-gray-400 text-center"><?php echo e($total_female); ?></td>
                <td class="border border-gray-400 text-center"><?php echo e($total_male + $total_female); ?></td>
            </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('reports.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/reports/rf-1f.blade.php ENDPATH**/ ?>