<?php $__env->startSection("title", "Demographics Profile"); ?>
<?php $__env->startSection("nav_title", "PATIENT SURVEILLANCE FORM"); ?>
<?php $__env->startSection("content"); ?>
<?php
    $data = App\Models\Demographicprofile::with(['cancerdiagnoses'])
        ->where("hospitalID", request()->query('hospitalID'))
        ->where('status', 1)
        ->first();
?>

<form id="form" method="POST" action="<?php echo e(route('store.f3patientsurveillanceforms', ['hospitalID' => request()->query('hospitalID')])); ?>">
    <?php echo csrf_field(); ?>
    <div class="card rounded-0">
        <div class="card-body rounded-0">

            <!-- Date -->
            <div class="mb-3">
                <label class="form-label fw-bold">Date <small class="text-danger">*</small></label>
                <input type="date" name="date" class="form-control"
                       value="<?php echo e(old('date', \Carbon\Carbon::now()->format('Y-m-d'))); ?>">
            </div>

            <!-- Name of Patient -->
            <div class="mb-3">
                <div class="row">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">First Name <small class="text-danger">*</small></label>
                        <input type="text" name="name[firstname]" class="form-control"
                               value="<?php echo e(old('name.firstname', $data->name['firstname'] ?? '')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Middle Name</label>
                        <input type="text" name="name[middlename]" class="form-control"
                               value="<?php echo e(old('name.middlename', $data->name['middlename'] ?? '')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Last Name <small class="text-danger">*</small></label>
                        <input type="text" name="name[lastname]" class="form-control"
                               value="<?php echo e(old('name.lastname', $data->name['lastname'] ?? '')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Suffix <small class="text-danger">*</small></label>
                        <input type="text" name="name[suffix]" class="form-control"
                               value="<?php echo e(old('name.suffix', $data->name['suffix'] ?? '')); ?>">
                    </div>
                </div>
            </div>

            <!-- Primary Cancer Site -->
            <div class="mb-3">
                <label class="form-label fw-bold">Primary Cancer Site <small class="text-danger">*</small></label>
                <div class="row">
                    <div class="col-md-4">
                        <?php $__currentLoopData = [
                            'Adrenal','Anus','Biliary Tract','Blood - Acute Lymphocytic Leukemia',
                            'Blood - Acute Myelogenous Leukemia','Blood - Chronic Lymphocytic Leukemia',
                            'Blood - Chronic Myelogenous Leukemia','Blood - Myelodysplastic Syndromes',
                            'Blood - Plasma Cell Disorders','Bone','Brain (CNS)','Breast','Cervix',
                            'Colon','Esophagus','Eyes and Orbit','Gallbladder','Gastroesophageal Junction',
                            'Hodgkin Lymphoma','Hypopharynx'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="primary_cancer_site[]" value="<?php echo e($label); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(in_array($label, $data->cancerdiagnoses['cancer_sites'] ?? []) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-4">
                        <?php $__currentLoopData = [
                            'Kaposi Sarcoma','Kidney','Larynx','Leukemia','Lip/Oral Cavity','Liver',
                            'Lung','Melanoma of Skin','Mesothelioma','Multiple Myeloma','Nasopharynx',
                            'Non-Hodgkin Lymphoma','Oral Cavity','Oropharynx','Ovary','Pancreas',
                            'Paranasal Sinus','Peritoneal','Prostate','Rectum'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="primary_cancer_site[]" value="<?php echo e($label); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(in_array($label, $data->cancerdiagnoses['cancer_sites'] ?? []) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-4">
                        <?php $__currentLoopData = [
                            'Renal Pelvis/Ureters','Salivary Glands','Skin','Small Bowel',
                            'Soft Tissue Sarcoma','Spinal Cord','Stomach','Testis','Thymus',
                            'Thyroid','Unknown Primary (Occult Primary)','Urinary Bladder',
                            'Uterus','Vagina','Vulva'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="primary_cancer_site[]" value="<?php echo e($label); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(in_array($label, $data->cancerdiagnoses['cancer_sites'] ?? []) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" name="primary_cancer_site_other"
                               value="<?php echo e(old('primary_cancer_site_other', $data->cancerdiagnoses['cancer_site_other'] ?? '')); ?>"
                               class="form-control mt-1" placeholder="Please Specify:">
                    </div>
                </div>
            </div>

            <!-- Laterality -->
            <div class="mb-3">
                <label class="form-label fw-bold">Laterality <small class="text-danger">*</small></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Left','Right','Bilateral','Not applicable','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="radio" name="laterality" value="<?php echo e($label); ?>"
                                class="form-check-input rounded-circle"
                                <?php echo e(old('laterality', $data->cancerdiagnoses['laterality'] ?? '') == $label ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($label); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Histologic Diagnosis -->
            <div class="mb-3">
                <label class="form-label fw-bold">Histologic Diagnosis <small class="text-danger">*</small></label>
                <input type="text" name="histologic_diagnosis" class="form-control"
                       value="<?php echo e(old('histologic_diagnosis', $data->cancerdiagnoses['histologic_diagnosis'] ?? '')); ?>">
            </div>

            <!-- ICD-10 -->
            <div class="mb-3">
                <label class="form-label fw-bold">ICD-10 <small class="text-danger">*</small></label>
                <input type="text" name="icd10" class="form-control"
                       value="<?php echo e(old('icd10', $data->cancerdiagnoses['icd_10'] ?? '')); ?>">
            </div>

            <!-- Group Clinical Stage -->
            <div class="mb-3">
                <label class="form-label fw-bold">Group Clinical Stage <small class="text-danger">(Optional)</small></label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = ['Stage 0','Stage I','Stage II','Stage III','Stage IV','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="radio" name="clinical_stage" value="<?php echo e($label); ?>"
                                class="form-check-input rounded-circle"
                                <?php echo e(old('clinical_stage', $data->cancerdiagnoses['clinical_stage'] ?? '') == $label ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($label); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- TNM -->
            <?php
                $tumors = ['t' => 'T (Tumor)','n' => 'N (Nodes)','m' => 'M (Metastasis)','s' => 'S (Staging)'];
            ?>
            <div class="row">
                <?php $__currentLoopData = $tumors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tumor => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <label class="form-label fw-bold"><?php echo e($label); ?> <span class="text-muted">(Optional)</span></label>
                        <input type="text" name="stage[<?php echo e($tumor); ?>_stage]" class="form-control"
                               value="<?php echo e(old('stage.'.$tumor.'_stage', $data->cancerdiagnoses[$tumor.'_stage'] ?? '')); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Other Staging Used -->
            <div class="mb-3 mt-3">
                <label class="form-label fw-bold">Other Staging Used <small class="text-danger">(Optional)</small></label>
                <div class="row">
                    <div class="col-md-6">
                        <?php $__currentLoopData = [
                            'FIGO Staging System (International Federation of Gynecology and Obstetrics)',
                            'Ann Arbor Staging System',
                            'Breslow Thickness and Clark Level (for Skin Cancer)',
                            'Durie-Salmon Staging System',
                            'Biomarker/Hormone Receptor Status'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="other_staging[]" value="<?php echo e($label); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(in_array($label, old('other_staging', $data->cancerdiagnoses['other_staging'] ?? [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-6">
                        <?php $__currentLoopData = [
                            'The Child-Pugh Score (for Liver Cancer)',
                            'Enneking Classification',
                            'Musculoskeletal Tumor Society (MSTS) classification',
                            'Nottingham Grading System',
                            'Not Applicable'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="other_staging[]" value="<?php echo e($label); ?>"
                                    class="form-check-input rounded-circle"
                                    <?php echo e(in_array($label, old('other_staging', $data->cancerdiagnoses['other_staging'] ?? [])) ? 'checked' : ''); ?>>
                                <label class="form-check-label"><?php echo e($label); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Other Remarks -->
            <div class="mb-3">
                <label class="form-label fw-bold">Other Remarks</label>
                <textarea name="other_remarks" class="form-control" rows="2"><?php echo e(old('other_remarks', $data->cancerdiagnoses['other_remarks'] ?? '')); ?></textarea>
            </div>

        </div>
    </div>

    <!-- Submit -->
    <div class="card-footer text-end">
        <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
        <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/forms/form3/patient-surveillance-form.blade.php ENDPATH**/ ?>