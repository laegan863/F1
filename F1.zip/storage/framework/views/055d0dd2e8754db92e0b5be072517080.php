<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
        <i class="fa fa-info"></i> <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/admin/component/session-alert.blade.php ENDPATH**/ ?>