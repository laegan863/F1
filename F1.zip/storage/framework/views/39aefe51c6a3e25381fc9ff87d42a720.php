<?php $__env->startSection("title", "Cancer Diagnosis Profile"); ?>
<?php $__env->startSection("nav_title", "PROFILE OF CANCER DIAGNOSIS OF PATIENT FORM"); ?>
<?php $__env->startSection("content"); ?>
<form id="form" method="POST" action="<?php echo e(route('submit-cancer-diagnose-data')); ?>">
    <?php echo csrf_field(); ?>
    <div class="card-body p-5">

        
        <div class="mb-3">
            <label class="form-label fw-bold">Are there more than 1 active Primary Cancer Site(s)? <small class="text-danger">*</small></label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input rounded-circle" type="radio"
                       name="multiple_sites" value="yes"
                       onclick="handleMultipleSite('yes')"
                       <?php echo e(old('multiple_sites') == 'yes' ? 'checked' : ''); ?>>
                <label class="form-check-label">Yes</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input rounded-circle" type="radio"
                       name="multiple_sites" value="no"
                       onclick="handleMultipleSite('no')"
                       <?php echo e(old('multiple_sites', 'no') == 'no' ? 'checked' : ''); ?>>
                <label class="form-check-label">No</label>
            </div>
        </div>

        
        <div id="active_primary_cancer" class="<?php echo e(old('multiple_sites') == 'yes' ? '' : 'd-none'); ?>">
            <div class="mb-3">
                <label class="form-label fw-bold">Primary Cancer Site Number <small class="text-danger">*</small></label>
                <input type="number" class="form-control"
                       name="primary_site_number" min="1"
                       value="<?php echo e(old('primary_site_number')); ?>">
            </div>
        </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Primary Cancer Site <small class="text-danger">*</small></label>
                <div class="row">
                    <?php
                        $sites = [
                            "Adrenal","Anus","Biliary Tract",
                            "Blood - Acute Lymphocytic Leukemia",
                            "Blood - Acute Myelogenous Leukemia",
                            "Blood - Chronic Lymphocytic Leukemia",
                            "Blood - Chronic Myelogenous Leukemia",
                            "Blood - Myelodysplastic Syndromes",
                            "Blood - Plasma Cell Disorders",
                            "Bone","Brain (CNS)","Breast","Cervix","Colon",
                            "Esophagus","Eyes and Orbit","Gallbladder",
                            "Gastroesophageal Junction","Hodgkin Lymphoma",
                            "Hypopharynx","Kaposi Sarcoma","Kidney","Larynx",
                            "Leukemia","Lip/Oral Cavity","Liver","Lung",
                            "Melanoma of Skin","Mesothelioma","Multiple Myeloma",
                            "Nasopharynx","Non-Hodgkin Lymphoma","Oral Cavity",
                            "Oropharynx","Ovary","Pancreas","Paranasal Sinus",
                            "Peritoneal","Prostate","Rectum","Renal Pelvis/Ureters",
                            "Salivary Glands","Skin","Small Bowel",
                            "Soft Tissue Sarcoma","Spinal Cord","Stomach","Testis",
                            "Thymus","Thyroid","Unknown Primary (Occult Primary)",
                            "Urinary Bladder","Uterus","Vagina","Vulva"
                        ];
                    ?>
                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input rounded-circle" type="checkbox"
                                   name="cancer_sites[]" value="<?php echo e($site); ?>"
                                   id="site<?php echo e($index); ?>"
                                   <?php echo e(in_array($site, old('cancer_sites', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="site<?php echo e($index); ?>"><?php echo e($site); ?></label>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-12 mt-2">
                        <label class="form-label">Others, specify:</label>
                        <input type="text" name="cancer_site_other"
                               class="form-control mt-1"
                               value="<?php echo e(old('cancer_site_other')); ?>">
                    </div>
                </div>
            </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">Laterality <small class="text-danger">*</small></label><br>
            <?php $__currentLoopData = ['Left','Right','Bilateral','Not Applicable']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                    <input type="radio" class="form-check-input rounded-circle"
                           name="laterality" value="<?php echo e($lat); ?>"
                           <?php echo e(old('laterality') == $lat ? 'checked' : ''); ?>>
                    <label class="form-check-label"><?php echo e($lat); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">ICD-10 <small class="text-danger">*</small></label>
            <input type="text" class="form-control"
                   name="icd_10" placeholder="e.g. C50.0"
                   value="<?php echo e(old('icd_10')); ?>">
        </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">Histologic Diagnosis <small class="text-danger">*</small></label>
            <input type="text" class="form-control"
                   name="histologic_diagnosis" placeholder="Enter diagnosis"
                   value="<?php echo e(old('histologic_diagnosis')); ?>">
        </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">Group Clinical Stage <small class="text-danger">(Optional)</small></label><br>
            <?php $__currentLoopData = ['Stage 0','Stage I','Stage II','Stage III','Stage IV','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input rounded-circle" type="radio"
                           name="clinical_stage" value="<?php echo e($stage); ?>"
                           <?php echo e(old('clinical_stage') == $stage ? 'checked' : ''); ?>>
                    <label class="form-check-label"><?php echo e($stage); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="row mb-3">
            <div class="col-md-3">
                <label class="form-label fw-bold">T (Tumor) <small class="text-danger">optional</small></label>
                <input type="text" class="form-control" name="t_stage" value="<?php echo e(old('t_stage')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold">N (Nodes) <small class="text-danger">optional</small></label>
                <input type="text" class="form-control" name="n_stage" value="<?php echo e(old('n_stage')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold">M (Metastasis) <small class="text-danger">optional</small></label>
                <input type="text" class="form-control" name="m_stage" value="<?php echo e(old('m_stage')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold">S (Staging) <small class="text-danger">optional</small></label>
                <input type="text" class="form-control" name="s_stage" value="<?php echo e(old('s_stage')); ?>">
            </div>
        </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">Other Staging Used <small class="text-danger">(Optional)</small></label>
            <div class="row">
                <?php
                    $staging_systems = [
                        "FIGO Staging System (International Federation of Gynecology and Obstetrics)",
                        "Ann Arbor Staging System",
                        "Breslow Thickness and Clark Level (for Skin Cancer)",
                        "Durie-Salmon Staging System",
                        "Biomarker/Hormone Receptor Status",
                        "The Child-Pugh Score (for Liver Cancer)",
                        "Enneking Classification",
                        "Musculoskeletal Tumor Society (MSTS) classification",
                        "Nottingham Grading System",
                        "Not Applicable"
                    ];
                ?>
                <?php $__currentLoopData = $staging_systems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $system): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input rounded-circle" type="checkbox"
                               name="other_staging[]" value="<?php echo e($system); ?>"
                               id="staging<?php echo e($i); ?>"
                               <?php echo e(in_array($system, old('other_staging', [])) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="staging<?php echo e($i); ?>"><?php echo e($system); ?></label>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="form-check">
                        <input placeholder="Other Remarks" class="form-control" type="text" name="other_remarks" value="<?php echo e(old('other_remarks')); ?>">
                    </div>
                </div>
            </div>
        </div>

        
        <div class="mb-3">
            <label class="form-label fw-bold">Current Status of the Cancer <small class="text-danger">*</small></label><br>
            <?php
                $statuses = [
                    "Newly diagnosed",
                    "Old case, not treated",
                    "Old case, completed 1st treatment, now recurrent",
                    "Old case, incomplete treatment, now progressive",
                    "Old case, unknown treatment"
                ];
            ?>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input rounded-circle" type="radio"
                           name="cancer_status" value="<?php echo e($status); ?>"
                           id="status<?php echo e($i); ?>"
                           <?php echo e(old('cancer_status') == $status ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="status<?php echo e($i); ?>"><?php echo e($status); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

    <div class="card-footer text-end">
        <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
        <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function handleMultipleSite(value) {
        let active_primary_cancer = document.getElementById('active_primary_cancer');
        if (value === "yes") {
            active_primary_cancer.classList.remove('d-none');
        } else {
            active_primary_cancer.classList.add('d-none');
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Laegan\F1\resources\views/forms/cancer-diagnose.blade.php ENDPATH**/ ?>