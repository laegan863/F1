<?php $__env->startSection("title", "Cancer Diagnosis Outcome"); ?>
<?php $__env->startSection("nav_title", "CANCER DIAGNOSIS OUTCOME"); ?>
<?php $__env->startSection("content"); ?>
    <form id="form" method="POST" action="<?php echo e(route('store.cancerdiagnoseoutcome')); ?>">
        <?php echo csrf_field(); ?>

        <div class="card shadow-sm">
            <div class="card-body">

                <!-- Diagnosis Outcome -->
                <h5 class="fw-bold">Diagnosis Outcome <small class="text-danger">*</small></h5>
                <div class="mb-3">
                    <div class="row">
                        <?php $__currentLoopData = [
                            'Stable Disease',
                            'Complete Remission',
                            'Partial Response',
                            'Disease Progression',
                            'Recurrent Disease',
                            'Death (Cancer related)',
                            'Death (treatment related)',
                            'Death (other Cause/Non-Cancer Related)',
                            'Ongoing evaluation',
                            'Ongoing treatment',
                            'Completed treatment',
                            'Undetermined'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" 
                                           name="diagnosis_outcome[]" 
                                           value="<?php echo e($label); ?>" 
                                           class="form-check-input rounded-circle"
                                           <?php echo e(in_array($label, old('diagnosis_outcome', [])) ? 'checked' : ''); ?>>
                                    <label class="form-check-label"><?php echo e($label); ?></label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['diagnosis_outcome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Date of Diagnosis Outcome -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Date of Diagnosis Outcome <small class="text-danger">*</small></label>
                    <input type="date" name="diagnosis_outcome_date" class="form-control" value="<?php echo e(old('diagnosis_outcome_date')); ?>">
                    <?php $__errorArgs = ['diagnosis_outcome_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Cause of Death -->
                <h5 class="fw-bold mt-3">Cause of Death <small class="text-danger">*</small></h5>
                <div class="mb-2">
                    <label class="form-label">Immediate Cause</label>
                    <input type="text" name="cause_immediate" class="form-control" value="<?php echo e(old('cause_immediate')); ?>">
                    <?php $__errorArgs = ['cause_immediate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-2">
                    <label class="form-label">Antecedent Cause <small class="text-danger">*</small></label>
                    <input type="text" name="cause_antecedent" class="form-control" value="<?php echo e(old('cause_antecedent')); ?>">
                    <?php $__errorArgs = ['cause_antecedent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-2">
                    <label class="form-label">Underlying Cause <small class="text-danger">*</small></label>
                    <input type="text" name="cause_underlying" class="form-control" value="<?php echo e(old('cause_underlying')); ?>">
                    <?php $__errorArgs = ['cause_underlying'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-2">
                    <label class="form-label">Other significant condition directly leading to death <small class="text-danger">*</small></label>
                    <input type="text" name="cause_other" class="form-control" value="<?php echo e(old('cause_other')); ?>">
                    <?php $__errorArgs = ['cause_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="card-footer text-end">
                <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
                <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/forms/form3/cancer-diagnose-outcome.blade.php ENDPATH**/ ?>