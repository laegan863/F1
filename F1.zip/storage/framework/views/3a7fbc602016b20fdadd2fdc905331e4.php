<?php $__env->startSection("title", "Cancer Treatment History"); ?>
<?php $__env->startSection("nav_title", "CANCER TREATMENT HISTORY"); ?>
<?php $__env->startSection("content"); ?>
    <form id="form" method="POST" action="<?php echo e(route('store.treatment-history')); ?>" class="p-2">
        <?php echo csrf_field(); ?>

        <!-- ================= SURGERY ================= -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Surgery <small class="text-danger">*</small></h5>
                <?php $__currentLoopData = [
                    'first'=>'Surgery Done?',
                    'second'=>'Second Surgery',
                    'third'=>'Third Surgery',
                    'fourth'=>'Fourth Surgery'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-3 mb-3">
                        <label class="form-label"><?php echo e($label); ?></label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_surgery" value="Yes"
                                class="form-check-input rounded-circle"
                                onclick="toggleSection('<?php echo e($key); ?>SurgeryDetails')"
                                <?php echo e(old($key.'_surgery') == 'Yes' ? 'checked' : ''); ?>>
                            <label class="form-check-label">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_surgery" value="No"
                                class="form-check-input rounded-circle"
                                onclick="toggleSection('<?php echo e($key); ?>SurgeryDetails')"
                                <?php echo e(old($key.'_surgery','No') == 'No' ? 'checked' : ''); ?>>
                            <label class="form-check-label">No</label>
                        </div>

                        
                        <div id="<?php echo e($key); ?>SurgeryDetails"
                            class="<?php echo e(old($key.'_surgery') == 'Yes' ? '' : 'd-none'); ?> mt-2">
                            <label class="form-label">Surgery Date</label>
                            <input type="date" name="<?php echo e($key); ?>_surgery_date"
                                class="form-control mb-2"
                                value="<?php echo e(old($key.'_surgery_date')); ?>">

                            <label class="form-label">What surgery type (RVS Code / Description) <small class="text-danger">*</small></label>
                            <input type="text" name="<?php echo e($key); ?>_surgery_code"
                                class="form-control mb-2" placeholder="RVS Code"
                                value="<?php echo e(old($key.'_surgery_code')); ?>">
                            <input type="text" name="<?php echo e($key); ?>_surgery_desc"
                                class="form-control mb-2" placeholder="Description"
                                value="<?php echo e(old($key.'_surgery_desc')); ?>">

                            <label class="form-label">Goal (can be multiple) <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['Diagnostic','Curative','Palliative','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="checkbox" name="<?php echo e($key); ?>_goal[]" value="<?php echo e($val); ?>"
                                            class="form-check-input rounded-circle"
                                            <?php echo e(in_array($val, old($key.'_goal', [])) ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <label class="form-label mt-2">Is there medically confirmed adverse event? <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['None','Minor','Major','Serious','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="radio" name="<?php echo e($key); ?>_adverse_event"
                                            value="<?php echo e($val); ?>"
                                            class="form-check-input rounded-circle"
                                            <?php echo e(old($key.'_adverse_event') == $val ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <!-- ================= ANTI-CANCER DRUG ================= -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Anti-Cancer Drug <small class="text-danger">*</small></h5>
                <?php $__currentLoopData = [
                    'first'=>'First Line',
                    'second'=>'Second Line',
                    'third'=>'Third Line',
                    'fourth'=>'Fourth Line'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-3 mb-3">
                        <label class="form-label"><?php echo e($key == "first" ? 'Anti-cancer Drug' : $label.' : Anti-Cancer Drug'); ?></label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_drug" value="Yes" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>DrugDetails')"
                                   <?php echo e(old($key.'_drug') == 'Yes' ? 'checked' : ''); ?>>
                            <label class="form-check-label">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_drug" value="No" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>DrugDetails')"
                                   <?php echo e(old($key.'_drug','No') == 'No' ? 'checked' : ''); ?>>
                            <label class="form-check-label">No</label>
                        </div>

                        <div id="<?php echo e($key); ?>DrugDetails" class="d-none mt-2">
                            <label class="form-label">Purpose of Drug Administration <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['Neoadjuvant','Adjuvant','Palliative']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="radio" name="<?php echo e($key); ?>_purpose_administration" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                               <?php echo e(old($key.'_purpose_administration') == $val ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <label class="form-label mt-2">Drug Type/s (can be multiple) <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['Cytotoxic','Hormonal','Immunologic','Targeted']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="checkbox" name="<?php echo e($key); ?>_drug_type[]" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                               <?php echo e(in_array($val, old($key.'_drug_type', [])) ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <label class="form-label mt-2">Drug Regimen <small class="text-danger">*</small></label>
                            <input type="text" name="<?php echo e($key); ?>_drug_regimen" class="form-control" value="<?php echo e(old($key.'_drug_regimen')); ?>">

                            <label class="form-label mt-2">Drug Response <small class="text-danger">*</small></label>
                            <input type="text" name="<?php echo e($key); ?>_drug_response" class="form-control" value="<?php echo e(old($key.'_drug_response')); ?>">

                            <label class="form-label mt-2">Is there medically confirmed adverse event? <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['None','Minor','Major','Serious','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="radio" name="<?php echo e($key); ?>_drug_adverse" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                               <?php echo e(old($key.'_drug_adverse') == $val ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- ================= RADIOTHERAPY ================= -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Radiotherapy <small class="text-danger">*</small></h5>
                <?php $__currentLoopData = [
                    'first'=>'First Course',
                    'second'=>'Second Course',
                    'third'=>'Third Course',
                    'fourth'=>'Fourth Course'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-3 mb-3">
                        <label class="form-label"><?php echo e($key == "first" ? 'Radiotherapy' : $label.': Radiotherapy'); ?></label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_radio" value="Yes" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>RadioDetails')"
                                   <?php echo e(old($key.'_radio') == 'Yes' ? 'checked' : ''); ?>>
                            <label class="form-check-label">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_radio" value="No" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>RadioDetails')"
                                   <?php echo e(old($key.'_radio','No') == 'No' ? 'checked' : ''); ?>>
                            <label class="form-check-label">No</label>
                        </div>

                        <div id="<?php echo e($key); ?>RadioDetails" class="d-none mt-2">
                            <label class="form-label">If yes, indicate type <small class="text-danger">*</small></label>
                            <div class="row">
                                <?php $__currentLoopData = [
                                    '2D conventional','3DCRT','IMRT/VMAT','IORT',
                                    'Electron Therapy','Brachytherapy','SRS/SRT',
                                    'Proton Therapy'
                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="<?php echo e($key); ?>_radio_type[]" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                                   <?php echo e(in_array($val, old($key.'_radio_type', [])) ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e($val); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <input type="text" name="<?php echo e($key); ?>_radio_type_other" placeholder="Please Specify Others" class="form-control" value="<?php echo e(old($key.'_radio_type_other')); ?>">
                                </div>
                            </div>

                            <label class="form-label mt-2">Specify Sequence: <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <div class="form-check">
                                    <input type="radio" name="<?php echo e($key); ?>_sequence" value="Concurrent ChemoRT" class="form-check-input rounded-circle"
                                           <?php echo e(old($key.'_sequence') == 'Concurrent ChemoRT' ? 'checked' : ''); ?>>
                                    <label class="form-check-label">Concurrent ChemoRT  <small class="text-danger">*</small></label>
                                </div>
                                <div class="form-check">
                                    <input type="radio" name="<?php echo e($key); ?>_sequence" value="Sequential" class="form-check-input rounded-circle"
                                           <?php echo e(old($key.'_sequence') == 'Sequential' ? 'checked' : ''); ?>>
                                    <label class="form-check-label">Sequential <small class="text-danger">*</small></label>
                                </div>
                            </div>

                            <label class="form-label mt-2">Specify Treatment Goal: <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <div class="form-check"><input type="radio" name="<?php echo e($key); ?>_treatment_goal" value="Definitive" class="form-check-input rounded-circle" <?php echo e(old($key.'_treatment_goal') == 'Definitive' ? 'checked' : ''); ?>><label class="form-check-label">Definitive</label></div>
                                <div class="form-check"><input type="radio" name="<?php echo e($key); ?>_treatment_goal" value="Palliative" class="form-check-input rounded-circle" <?php echo e(old($key.'_treatment_goal') == 'Palliative' ? 'checked' : ''); ?>><label class="form-check-label">Palliative</label></div>
                            </div>

                            <label class="form-label mt-2">Is there medically confirmed adverse event? <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['None','Minor','Major','Serious','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="radio" name="<?php echo e($key); ?>_radio_adverse" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                               <?php echo e(old($key.'_radio_adverse') == $val ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- ================= THERANOSTICS ================= -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Theranostics <small class="text-danger">*</small></h5>
                <?php $__currentLoopData = [
                    'first'=>'First Line',
                    'second'=>'Second Line',
                    'third'=>'Third Line',
                    'fourth'=>'Fourth Line'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded p-3 mb-3">
                        <label class="form-label"><?php echo e($key == "first" ? 'Theranostics' : $label.': Theranostics'); ?></label>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_theranostics" value="Yes" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>TheraDetails')"
                                   <?php echo e(old($key.'_theranostics') == 'Yes' ? 'checked' : ''); ?>>
                            <label class="form-check-label">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="<?php echo e($key); ?>_theranostics" value="No" class="form-check-input rounded-circle"
                                   onclick="toggleSection('<?php echo e($key); ?>TheraDetails')"
                                   <?php echo e(old($key.'_theranostics','No') == 'No' ? 'checked' : ''); ?>>
                            <label class="form-check-label">No</label>
                        </div>

                        <div id="<?php echo e($key); ?>TheraDetails" class="d-none mt-2">
                            <label class="form-label">If yes, indicate type</label>
                            <div class="row">
                                <?php $__currentLoopData = [
                                    'Radioactive Iodine Therapy (RAI)','Peptide Receptor Radionuclide Therapy (PRRT)',
                                    'PSMA Radioligand Therapy (PRLT)', 'Selective Internal Radiation Therapy (SIRT)'
                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 my-2">
                                        <div class="form-check">
                                            <input type="checkbox" name="<?php echo e($key); ?>_thera_type[]" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                                   <?php echo e(in_array($val, old($key.'_thera_type', [])) ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e($val); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-8 my-2">
                                    <input type="text" placeholder="Please Specify Others" name="<?php echo e($key); ?>_theranostics_other_specify" class="form-control" value="<?php echo e(old($key.'_theranostics_other_specify')); ?>">
                                </div>
                            </div>

                            <label class="form-label mt-2">Specify the goal <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <div class="form-check"><input type="radio" name="<?php echo e($key); ?>_thera_goal" value="Definitive" class="form-check-input rounded-circle" <?php echo e(old($key.'_thera_goal') == 'Definitive' ? 'checked' : ''); ?>><label class="form-check-label">Definitive</label></div>
                                <div class="form-check"><input type="radio" name="<?php echo e($key); ?>_thera_goal" value="Palliative" class="form-check-input rounded-circle" <?php echo e(old($key.'_thera_goal') == 'Palliative' ? 'checked' : ''); ?>><label class="form-check-label">Palliative</label></div>
                            </div>

                            <label class="form-label mt-2">Is there medically confirmed adverse event? <small class="text-danger">*</small></label>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = ['None','Minor','Major','Serious','Unknown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input type="radio" name="<?php echo e($key); ?>_thera_adverse" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                               <?php echo e(old($key.'_thera_adverse') == $val ? 'checked' : ''); ?>>
                                        <label class="form-check-label"><?php echo e($val); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Other Cancer Directed Therapies <small class="text-danger">*</small></h5>

                <div class="form-check form-check-inline">
                    <input type="radio" name="other_cancer" value="Yes" class="form-check-input rounded-circle"
                        onclick="toggleSection('OtherCancerDetails')"
                        <?php echo e(old('other_cancer') == 'Yes' ? 'checked' : ''); ?>>
                    <label class="form-check-label">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" name="other_cancer" value="No" class="form-check-input rounded-circle"
                        onclick="toggleSection('OtherCancerDetails')"
                        <?php echo e(old('other_cancer','No') == 'No' ? 'checked' : ''); ?>>
                    <label class="form-check-label">No</label>
                </div>

                <div id="OtherCancerDetails" class="<?php echo e(old('other_cancer') == 'Yes' ? '' : 'd-none'); ?> mt-2">
                    <?php $__currentLoopData = [
                        'Blood Transfusion','Cryoablation','Embolization','Radiofrequency ablation',
                        'Transarterial chemoembolization','Transplant'
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="checkbox" name="other_cancer_type[]" value="<?php echo e($val); ?>" class="form-check-input rounded-circle"
                                <?php echo e(in_array($val, old('other_cancer_type', [])) ? 'checked' : ''); ?>>
                            <label class="form-check-label"><?php echo e($val); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="text" name="cancer_type_other_specify" placeholder="Please Specify Others"
                        class="form-control mt-2" value="<?php echo e(old('cancer_type_other_specify')); ?>">
                </div>
            </div>
        </div>


        <!-- ================= REMARKS ================= -->
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="fw-bold">Remarks <small class="text-danger">*</small></h5>
                <textarea name="remarks" class="form-control"><?php echo e(old('remarks')); ?></textarea>
            </div>
        </div>

        <!-- ================= SUBMIT ================= -->
        <div class="card-footer text-end mt-3">
            <button type="reset" class="btn btn-secondary rounded-0">Reset</button>
            <button type="button" onclick="handleSubmit()" class="btn btn-primary rounded-0">Submit</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script>
function toggleSection(id) {
    const div = document.getElementById(id);
    if (!div) return;

    // Normalize ID (capitalize-insensitive matching)
    const match = id.match(/^(first|second|third|fourth)?(Surgery|Drug|Radio|Thera|OtherCancer)Details$/i);
    if (!match) return;

    const prefix = match[1] || '';
    const type = match[2].toLowerCase();

    let inputName = '';
    switch (type) {
        case 'surgery': inputName = `${prefix}_surgery`; break;
        case 'drug': inputName = `${prefix}_drug`; break;
        case 'radio': inputName = `${prefix}_radio`; break;
        case 'thera': inputName = `${prefix}_theranostics`; break;
        case 'othercancer': inputName = `other_cancer`; break;
    }

    const yesRadio = document.querySelector(`input[name="${inputName}"][value="Yes"]`);
    const noRadio = document.querySelector(`input[name="${inputName}"][value="No"]`);

    if (yesRadio && yesRadio.checked) {
        div.classList.remove('d-none');
    } else if (noRadio && noRadio.checked) {
        div.classList.add('d-none');
    }
}

// Re-run toggles on page load for old() values
window.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('div[id$="Details"]').forEach(div => toggleSection(div.id));
});
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Laegan\F1\resources\views/forms/form3/cancer-treatment-history.blade.php ENDPATH**/ ?>